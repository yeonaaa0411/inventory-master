<?php

  define( 'DB_HOST', 'localhost' );          // Set database host
  define( 'DB_USER', 'root' );             // Set database user
  define( 'DB_PASS', 'p1r4sp' );             // Set database password
  define( 'DB_NAME', 'bpsr_inv' );        // Set database name

?>
